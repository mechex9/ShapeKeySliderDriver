bl_info = {  
    "name": "Shapekey Slider Driver",  
    "author": "Fernando Macias-Jimenez",  
    "version": (2, 0),  
    "blender": (2, 80, 0),  
    "location": "View3D > Add > Armature",  
    "description": "Creates a 3D-View UI slider to control a shape key.",  
    "warning": "",  
    "wiki_url": "",  
    "tracker_url": "",  
    "category": "Rigging"}

import bpy, bmesh
from math import pi

class ShapekeySliderCreator(bpy.types.Operator):
    """Shapekey Slider Driver"""
    bl_idname = "object.ssd"
    bl_label = "Shapekey Slider Driver"
    bl_options = {'REGISTER', 'UNDO'}
    
    mesh = []
    amt = bpy.props.PointerProperty()
    rig = bpy.props.PointerProperty()
    base = bpy.props.PointerProperty()
    slider = bpy.props.PointerProperty()
    baseObj = bpy.props.PointerProperty()
    sliderObj = bpy.props.PointerProperty()


    def createArmature(self):
        
        print("STARTING CREATE ARMATURE")
        # Create armature and object
        # arm = bpy.data.armatures.new("GUIcontrol_Armature")
        arm = bpy.ops.object.armature_add(radius=1.0, view_align=False, enter_editmode=False, location=(0.0, 0.0, 0.0), rotation=(0.0, 0.0, 0.0))
        ob = bpy.context.object
        ob.name = 'GUIcontrol_Armature'
        self.rig = ob
        
        print(ob.name)
        print("THAT WAS THE NEW SELECTED ARMATURE")
        
        self.amt = ob.data
        self.amt.name = 'GUIcontrol'
        # self.rig = bpy.data.objects.new("GUIcontrol", self.amt)
        # print(self.rig)
        # print("THAT WAS THE RIG")
        # self.rig.location : (0,0,0)
        # self.rig.show_x_ray : True
        # self.amt.show_names : True
        # Link object to scene
        # scn = bpy.context.scene
        # bpy.context.scene.objects.link : self.amt
        # bpy.context.scene.objects.link : self.rig

        bpy.context.scene.update()
     
        # Create bones
    
        print(self.amt)
        print("THAT WAS THE ARMATURE")
        
        bpy.ops.object.select_all(action='DESELECT')
        
        # bpy.context.scene.objects.select : bpy.data.objects['Cone']
        # bpy.context.view_layer.objects.select : self.amt
        # bpy.context.view_layer.objects.active = self.amt
        
        print(bpy.context.active_object)
        print("SELECTED OBJECT")
        
        bpy.ops.object.mode_set(mode = 'EDIT')

        armtoedit = self.amt        
        a = armtoedit.edit_bones.new('Base')
        a.head = (0,0,0)
        a.tail = (0,0,0.4)
        a.show_wire = True
        self.base = a
        print("BASE CREATED")
     
        b = armtoedit.edit_bones.new('Slider')
        b.head = (0,0,0.4)
        b.tail = (0,0,0.8)
        b.parent = self.base
        b.use_connect = False
        b.show_wire = True
        self.slider = b
        print("SLIDER CREATED")
        
        for bone in armtoedit.edit_bones:
            if (bone.name == "Bone"): 
                armtoedit.edit_bones.remove(bone)
        
        # bpy.context.view_layer.objects.active = self.arm
        print(bpy.context.object)
        print("OBJECT SELECTED BEFORE POSE MODE")
        
        bpy.ops.object.mode_set(mode='OBJECT')
        
        bpy.ops.object.mode_set(mode='POSE')
        
        slidered = bpy.context.object.pose.bones['Slider']
        slidered.lock_location[0] = True
        slidered.lock_location[2] = True
        slidered.custom_shape=bpy.data.objects[self.sliderObj.name]
        
        holder = bpy.context.active_object.pose.bones['Base']
        holder.custom_shape=bpy.data.objects[self.baseObj.name]
        
        pMid = bpy.context.object.pose.bones['Slider']
        cns1 = pMid.constraints.new('LIMIT_LOCATION')
        cns1.name = 'LocLimit'
        cns1.owner_space = 'LOCAL'
        cns1.use_min_y = True
        cns1.min_y = 0.0
        cns1.use_max_y = True
        cns1.max_y = 0.7
        cns1.use_transform_limit = True
        
        bpy.ops.object.mode_set(mode='OBJECT')
        
        return;
        
    def createText(self):

        loc = (0,0,0)
        #layers = 20*[False]
        #layers[18] = True
        bpy.ops.object.text_add(
        location=loc,
        rotation=(pi/2,0,0),
        #layers=layers
        )
        txt = bpy.context.object
        txt.name = "Text"
        txt.show_name = False
        tcu = txt.data
        tcu.name = "Text"
     
        # TextCurve attributes
        tcu.body = "Text"
        tcu.font = bpy.data.fonts[0]
        #tcu.offset_x = -9
        #tcu.offset_y = -0.25
        #tcu.shear = 0.5
        tcu.size = 0.2
        #tcu.space_character = 2
        #tcu.space_word = 4    
        txt.draw_type : 'WIRE'
        
        #arm = bpy.data.objects["GUIcontrol"]
        #txt = bpy.data.objects["Text"]
        txt.parent = self.rig
        
        txt.location = self.rig.location 
        txt.location.x = txt.location.x - 0.2
        txt.location.z = txt.location.z + 0.05
        
        return;
           
    def createShapes(self):
        
        #layers = 20*[False]
        #layers[19] = True
        #scn = bpy.context.scene
        #scn.layers[19] = True
        
        bpy.ops.mesh.primitive_plane_add(
        location=(0,0,0)
        )
        ob1 = bpy.context.object
        ob1.name = "S_Slider"
        pl1 = ob1.data
        pl1.name = "S_Slider"

        bpy.ops.mesh.primitive_plane_add(
        location=(0,0,0)
        )
        ob2 = bpy.context.object
        ob2.name = "S_Holder"
        pl2 = ob2.data
        pl2.name = "S_Holder"
        
        #resize Holder shape
        bpy.context.view_layer.objects.active = ob2
        print(bpy.context.object)
        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.transform.resize(value=(1.5,5.0,1))
        # bpy.ops.transform.resize(value=(0.25,0.25,1))
        bpy.ops.transform.translate(value=(0,7.5,0))
        bpy.ops.object.mode_set(mode = 'OBJECT')
        self.baseObj = bpy.context.object
        
        #resize Slider shape
        bpy.context.view_layer.objects.active = ob1
        print(bpy.context.object)
        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.transform.resize(value=(0.25,0.25,1))
        bpy.ops.transform.translate(value=(0,-2.8,0))
        bpy.ops.object.mode_set(mode = 'OBJECT')
        self.sliderObj = bpy.context.object
        
        # bpy.data.objects[ob1.name].hide_viewport = True
        # bpy.data.objects[ob2.name].hide_viewport = True
        
        bpy.context.scene.update()
        
        return;
    
    def createDriver(self):
        
        bpy.context.scene.objects.active : self.mesh[0]
        
        fc = bpy.context.active_object.active_shape_key.driver_add('value', -1)
        fc.driver.type = 'AVERAGE'
        dvar = fc.driver.variables.new()
        dvar.type = 'TRANSFORMS'
 
        dvar.targets[0].id = self.rig
        dvar.targets[0].bone_target = "Slider"
        dvar.targets[0].transform_type = 'LOC_Y'
        dvar.targets[0].transform_space = 'LOCAL_SPACE'
        
        fmod = fc.modifiers[0]
        fmod.coefficients = (0.0,1.428)
        
        return;
        
    def execute(self, context):
        
        self.mesh = bpy.context.selected_objects
        print(self.mesh)
        print()
        self.createShapes()
        self.createArmature()
        self.createText()
        if self.mesh:
            if self.mesh[0].type == 'MESH':
                bpy.context.view_layer.objects.active = self.mesh[0]
                if bpy.context.active_object.active_shape_key:
                    self.createDriver()
                    
        bpy.ops.object.select_all(action='DESELECT')
        bpy.context.view_layer.objects.active = self.baseObj
        bpy.data.objects[self.baseObj.name].select_set(True)
        bpy.ops.object.delete()
        
        bpy.ops.object.select_all(action='DESELECT')
        bpy.context.view_layer.objects.active = self.sliderObj
        bpy.data.objects[self.sliderObj.name].select_set(True)
        bpy.ops.object.delete()
        
        bpy.ops.object.select_all(action='DESELECT')
        
        bpy.context.view_layer.objects.active = self.rig
        
        bpy.context.object.select_set(state=True)
            
        return {'FINISHED'}
  
def add_object_button(self, context):  
    self.layout.operator(  
        ShapekeySliderCreator.bl_idname,  
        text=ShapekeySliderCreator.__doc__,  
        icon='PLUGIN') 

def register():  
    from bpy.utils import register_class
    register_class(ShapekeySliderCreator)

    bpy.types.VIEW3D_MT_armature_add.append(add_object_button)
    #from bpy.types import INFO_MT_armature_add
    #INFO_MT_armature_add.append(add_object_button)
    #bpy.types.INFO_MT_mesh_add.append(add_object_button)
    
def unregister():
    from bpy.utils import unregister_class
    unregister_class(ShapekeySliderCreator) 

    bpy.types.VIEW3D_MT_armature_add.remove(add_object_button)
    #from bpy.types import INFO_MT_armature_add
    #INFO_MT_armature_add.remove(add_object_button)
    #bpy.types.INFO_MT_mesh_add.remove(add_object_button)
    
if __name__ == "__main__":
    try:
        unregister()
    except:
        pass
    register() 